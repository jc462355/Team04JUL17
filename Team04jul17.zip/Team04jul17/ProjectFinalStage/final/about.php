 	<?php include("h1.php") ?>


	<section id="one"> 
	<div class="inner"> 
	<header> 
	<h2 class="pro">Our Profile</h2> 

	</header> 
	<img src="img/pic_1.jpg" height="auto" width="auto" class="about_img" >
	
	
	<p >Event Association was founded by Managing Director, Amy Merriman in Sydney in 2001.

The business grew quickly and gained a strong reputation throughout Australia for creating and professionally managing innovative and impactful events that impressed both clients and guests alike.Over a decade later, Event Association comprises a talented and diversely skilled team of full-time Event Producers, Event Managers and Event Coordinators and is regarded as one of Australia’s most respected and reliable event management companies, producing a wide range of events for businesses and organisations in the corporate and government sectors.In recent years, Event Planet has added a number of high profile Australian Federal Government departments and agencies into the client portfolio, having produced the National Broadband Network Forum and the Digital Television Switchover Conference for the Department of Broadband, Communications and the Digital Economy. Additionally, the company has produced the inaugural National e-Health Conference, the Australian Indigenous Leadership Forum and a number of key, multi-stakeholder events for Infrastructure Australia.
Event Planet has been recognised as the premier event management company in Australia by consecutively winning the prestigious and coveted Event Manager of the Year award at both the 2012 and 2013 Australian Event Awards. In the history of the awards, Event Planet is the only company to win the title more than once, let alone in back-to-back years.
</p> 

	 
	<a href="#" style="margin-left:500px;">Read More</a>

	
	</div> 
	</section> 
	
    <section id="two" > 
	<div class="inner"> 
	<article> 
	<header> 
	<h2 style="text-align:center;background-color:black;">Our Event Planning Awards</h2> 
 
<p>2017, Best Non-proft Event, Budget Over $200,000</p>
<p>2017, Best Corporate Event, Budget Under $75,000</p>
<p>2017, Best Meeting-Conference Program, Budget Under $250,000</p>
<p>2015, Best Marketing-Design Collateral, Budget Under $25,000</p>
	
	
	</header> 
	
    </marquee> 
	</article> 
	<article class="alt"> 
	<div class="content"> 
	<h2 style="text-align:center;background-color:black;">Become The Special Event Company’s Next Client</h2> 
 
<p>If you’re interested in being our next client, why not start planning your upcoming event with The Special Event Company? Contact our event specialists in Cary, NC today!Our team of professional planners has produced events such as corporate sales events, press conferences and academic events all over the world. View our online portfolio to see work we’ve done for previous clients and how memorable your next event can be. Our meeting and event planning services are comprehensive, offering logistics, speakers</p>
	
   


	 </div> 
	</article> 
	</div> 
	</section> 
	
	
	
	
	<section id="footer"> 
	<div class="inner"> 
	<div class="copyright"> 
	&copy; Event Association: <a href="">Team 04</a> Images <a href="#">Event</a> All rights reserved.

	</div> 
	</div> 
	</section> 
	
	
	
	</body> 
	</html> 
	

