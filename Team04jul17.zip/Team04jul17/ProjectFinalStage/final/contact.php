

	
	
	
	 	<?php include("h1.php") ?>

	
	

	<section id="one"> 
	<div class="inner"> 
	<header> 
	<h2 class="pro">Contact Us</h2> 

	
            
			How to get in touch with us:
		
	<p>For all sales, internet or general enquiries please use the phone and contact details below, or you can use the contact us form at the bottom of this page.
Contact Details
	Phone No: 	+6146454545
	<br>
	Phone No: 	+6144547457
 Email: 	info@eventassociation.com.au			
</p>
<br><br>


<h2 class="pro">Get In Touch With Us</h2> 

<form name="frmContact" method="post" action="">

<div class="aler_message"><?php if(isset($message)) { echo $message; } ?></div>

<table border="0" cellpadding="10" cellspacing="1" width="500" align="center">
<tr class="tableheader">
<td colspan="2">Contact Form</td>
</tr>
<tr class="tablerow">
<td>Full Name<br/>  <input type="text" class="text_input" autofocus="autofocus" name="fullname"></td>
<td>Email<br/> <input type="text" class="text_input" autofocus="autofocus" name="email"></td>
</tr>
<tr class="tablerow">
<td colspan="2">Message<br/><textarea name="user_message" class="text_input" autofocus="autofocus" cols="60" rows="6"></textarea></td>
</tr>
<tr class="tableheader">
<td colspan="2"><input type="submit" class="btn_submit" name="submit" value="Submit"></td>
</tr>
</table>

</form>

   
		   
		   
		   
		   
		
		 
        </form>
	
	</header> 
	
	
	</div> 
	</section> 
	
    
	<section id="footer"> 
	<div class="inner"> 
	<div class="copyright"> 
	&copy; Event Association: <a href="">Team 04</a> Images <a href="#">Event</a> All rights reserved.

	</div> 
	</div> 
	</section> 
	
	
	
	</body> 
	</html> 
	

