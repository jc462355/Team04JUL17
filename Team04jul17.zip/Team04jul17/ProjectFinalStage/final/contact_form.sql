-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 28, 2017 at 02:30 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `contact_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact`
--

DROP TABLE IF EXISTS `tbl_contact`;
CREATE TABLE IF NOT EXISTS `tbl_contact` (
  `tbl_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `user_message` varchar(100) NOT NULL,
  PRIMARY KEY (`tbl_contact_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_contact`
--

INSERT INTO `tbl_contact` (`tbl_contact_id`, `fullname`, `email`, `user_message`) VALUES
(5, 'Priyanshu Raj', 'example@email.com', 'Hi . I have a question? '),
(6, 'Raj', 'example@email.com', 'This is testing message..'),
(7, 'Mohit...', 'example@email.com', 'Hello. I am mohit I want to create a website.. please tell me how to create it.'),
(8, 'jhjhgjhj', 'ghfhfghf', 'jvgcgfghhffgh'),
(9, 'jhjhgjhj', 'ghfhfghf', 'jvgcgfghhffgh'),
(10, 'jhjhgjhj', 'ghfhfghf', 'jvgcgfghhffgh'),
(11, 'jhjhgjhj', 'ghfhfghf', 'jvgcgfghhffgh'),
(12, 'jhjhgjhj', 'ghfhfghf', 'jvgcgfghhffgh'),
(13, 'hjgj', 'gjgj', 'hgjhg'),
(14, 'hjgj', 'gjgj', 'hgjhg'),
(15, 'hjgj', 'gjgj', 'hgjhg'),
(16, 'navjot', 'nav@gmail.com', 'hello i have a question regarding your site'),
(17, 'karam', 'karam@gmail.com', 'hello');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
