 	<?php include("h1.php") ?>
       
<section id="two" > 
<h1 class="concert">Current Events</h1><br/>
<h2 class="concert">Music Concerts</h2><br/>
	<div class="inner">
	<article> 
		<img src="img/chain.jpg" width="100%" height="60%"/>
	</article> 
<article class="alt"> 
	<div class="content"> 
<label for="text"><b>Event Name:</b></label>
<label type="text" style="font-style:italic; color:blue;">Chain Music Concert</label><br/>
<label for="text"><b>Event Type:</b></label>
<label type="text" style="font-style:italic; color:blue;">Music </label><br/>
<label for="text"><b>Event Date and Time:</b></label>
<label type="text" style="font-style:italic; color:blue;">2nd Oct,2017 and 17:00 </label><br/>
<label for="text"><b>Total No of seats:</b></label>
<label type="text" style="font-style:italic; color:blue;">300</label><br/>
<label for="text"><b>Price per person:</b></label>
<label type="text" style="font-style:italic; color:blue;">AUD$250</label><br/>
<label for="text"><b>Description:</b></label>
<label type="text" style="font-style:italic; color:blue;">The Chainsmokers is an American DJ/production duo consisting of Andrew Taggart and Alex Pall. The EDM-pop duo achieved a breakthrough with their 2014 song "#Selfie", which was a top twenty single in several countries.</label>
</div>
</article>
</section> 
<section id="two">
	<div class="inner">    
	<article> 
		<img src="img/backstreet.jpg" width="100%" height="60%"/>
	</article> 
<article class="alt"> 
	<div class="content"> 
<label for="text"><b>Event Name:</b></label>
<label type="text" style="font-style:italic; color:blue;">Backstreet Boys Music Concert</label><br/>
<label for="text"><b>Event Type:</b></label>
<label type="text" style="font-style:italic; color:blue;">Music </label><br/>
<label for="text"><b>Event Date and Time:</b></label>
<label type="text" style="font-style:italic; color:blue;">4th Oct,2017 and 17:00 </label><br/>
<label for="text"><b>Total No of seats:</b></label>
<label type="text" style="font-style:italic; color:blue;">300</label><br/>
<label for="text"><b>Price per person:</b></label>
<label type="text" style="font-style:italic; color:blue;">AUD$250</label><br/>
<label for="text"><b>Description:</b></label>
<label type="text" style="font-style:italic; color:blue;">The Backstreet Boys are an American vocal group, formed in Orlando, Florida in 1993. The group consists of AJ McLean, Howie D., Nick Carter, Kevin Richardson, and Brian Littrell.</label>
</div>
</article>
</div>
</section>
<section id="two" > 
<h2 class="concert">Dance Events</h2><br/>
	<div class="inner"> 
	<article> 
		<img src="img/mob.jpg" width="100%" height="100%"/>
</article> 
<article class="alt"> 
	<div class="content"> 
<label for="text"><b>Event Name:</b></label>
<label type="text" style="font-style:italic; color:blue;">Mob Dance Concert</label><br/>
<label for="text"><b>Event Type:</b></label>
<label type="text" style="font-style:italic; color:blue;">Dance </label><br/>
<label for="text"><b>Event Date and Time:</b></label>
<label type="text" style="font-style:italic; color:blue;">5th Oct,2017 and 17:00 </label><br/>
<label for="text"><b>Total No of seats:</b></label>
<label type="text" style="font-style:italic; color:blue;">300</label><br/>
<label for="text"><b>Price per person:</b></label>
<label type="text" style="font-style:italic; color:blue;">AUD$250</label><br/>
<label for="text"><b>Description:</b></label>
<label type="text" style="font-style:italic; color:blue;">"The MOB", shuts down Ocean Drive by cutting off the streets with retro convertibles and dancing on cars to music blasted by DJ Penelope (Cleopatra Coleman).</label>
</div>
</article>
</section> 
</div> 
</section> 
<section id="two" > 
<h2 class="concert">Other Events</h2><br/>
	<div class="inner"> 
	<article> 
		<img src="img/art.jpg" width="100%" height="60%"/>
	</article> 
<article class="alt"> 
	<div class="content"> 
<label for="text"><b>Event Name:</b></label>
<label type="text" style="font-style:italic; color:blue;">Husain's Art Gallery</label><br/>
<label for="text"><b>Event Type:</b></label>
<label type="text" style="font-style:italic; color:blue;">Art </label><br/>
<label for="text"><b>Event Date and Time:</b></label>
<label type="text" style="font-style:italic; color:blue;">7th Oct,2017 and 17:00 </label><br/>
<label for="text"><b>Total No of seats:</b></label>
<label type="text" style="font-style:italic; color:blue;">300</label><br/>
<label for="text"><b>Price per person:</b></label>
<label type="text" style="font-style:italic; color:blue;">AUD$50</label><br/>
<label for="text"><b>Description:</b></label>
<label type="text" style="font-style:italic; color:blue;">Maqbool Fida Husain was a modern Indian painter of international acclaim, and a founding member of Bombay Progressive Artists' Group. Husain was associated with Indian modernism in the 1940s.</label>
</div>
</article>
</section> 
<h2 style="color:red; font-style:italic, bold; font-family:Palatino; font-size:inherit">
Note:- For booking please <a href="contact.php" style="color:blue;"><i>contact here</i></a>
</h2>
<section id="footer"> 
	<div class="inner"> 
	<div class="copyright"> 
	&copy; Event Association: <a href="https://templated.co/">Team 04</a><a href="#">Event</a> 
	</div> 
	</div> 
	</section>
	</body> 
	</html> 
	

