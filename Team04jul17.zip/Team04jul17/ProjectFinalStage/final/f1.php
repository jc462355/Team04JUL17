<head> 
	<title>Event Association</title> 
	<meta charset="utf-8" /> 
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" /> 
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
<link rel="stylesheet" href="css/main.css" /> 
<script src="js/member.js"></script>
<script src="js/nav.js"></script>	<script src="assets/js/jquery.min.js"></script> 

	<script src="assets/js/skel.min.js"></script> 

	<script src="assets/js/util.js"></script> 

	<script src="assets/js/main.js"></script> 


	</head> 

<section id="footer"> 
	<div class="inner"> 
	<div class="copyright"> 
	&copy; Event Association: <a href="https://templated.co/">Team 04</a><a href="#">Event</a> 

	</div> 
	</div> 
	</section> 