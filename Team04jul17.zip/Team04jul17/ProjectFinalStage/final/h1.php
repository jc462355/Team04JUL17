	<!DOCTYPE HTML> 
	
	<html> 
	<head> 
	<title>Event Association</title> 
	<meta charset="utf-8" /> 
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" /> 
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
    <link rel="stylesheet" href="css/main.css" /> 
<link href="css/rwd.css" rel="stylesheet" type="text/css">
<link href="css/nav_responsive.css" rel="stylesheet" type="text/css">
<link href="css/nav.css" rel="stylesheet" type="text/css">
<

	</head> 
	<body>
	<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>

      
	 <header id="header"> 
	<div class="inner"> 
	<a href="index.php" class="logo">Event Association</a> 

	
   
   
   
   <div class="topnav" id="myTopnav">
	<ul class="top-level-menu" id="top_menu">
 <li> <a href="index.php">Home</a></li>
  <li><a href="about.php">About</a></li>
  <li><a href="contact.php">Contact</a></li>
  <li><a href="event.php">Event</a></li>
<?php if(isset($_SESSION['valid_user'])): ?>
        <li><a href="logout.php" id="4" onClick="nav_item_selected(4)">Sign-out</a></li>
        <?php else: ?>
		<li><a href="login.php" id="4" onClick="nav_item_selected(4)">Sign-in</a></li>
		<?php endif; ?>
		<li><a href="member.php" id="5" onClick="nav_item_selected(5)">Sign-up</a></li>
      

  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
  </ul>
</div>
	</div> 
	</header> 
	
    <?php 
		if(isset($_SESSION['valid_user'])) {
			$name = $_SESSION["name"];
			echo "<div style=\"clear: both;\"><p>$name</p></div>";
		}
		else {
			echo "<div style=\"clear: both;\"><p>&nbsp;</p></div>";
		}
	?>
