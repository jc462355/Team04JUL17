

      
 	<?php include("h1.php") ?>
    <div id="slider"> 
	<figure> 
	<img src="img/slide1.jpg"> 

	<img src="img/slide2.jpg"> 

	<img src="img/slide3.jpg"> 

	<img src="img/slide1.jpg"> 
    </figure> 
	</div> 
	

	<section id="one"> 
	<div class="inner"> 
	<header> 
	<h2>About Us</h2> 
	</header> 
            <p>
                
 Our company will help you to organise a number of different special events that your organisation may be interested in hosting. Ceremonies, celebrations,  sports events and events where you invite the public. You can ask our company to help you set up special meetings that your employees and/or business partners may need to attend.                
                
                
                
                
                
                
            </p>
	<ul class="actions"> 
	<li><a href="about.php" class="button alt">Read More</a></li> 

	</ul> 
	</div> 
	</section> 
	
    <section id="two" > 
	<div class="inner"> 
	<article> 
	<header> 
	<h3>Latest Events</h3> 
	</header> 
	<marquee onmouseover="this.stop();" onmouseout="this.start();" direction="up" scrollamount="3" height="150"> 
	<div class="panel-group" id="accordion"> 
	<div class="panel panel-default"> 
	<div class="panel-heading"> 
	<p class="panel-title" style="font-size: 100%"> 
	<a data-toggle="collapse" data-parent="#accordion" class="collapsed" href="event.php"> 

	Diwali Celebration
	</a><br> 
	<a data-toggle="collapse" data-parent="#accordion" class="collapsed" href="event.php"> 

	Christmas Celebration 
	</a><br> 
	<a data-toggle="collapse" data-parent="#accordion" class="collapsed" href="event.php"> 


	Volleyball Tournament 
	</a><br> 
	<a data-toggle="collapse" data-parent="#accordion" class="collapsed" href="event.php"> 


	New Year 2018
	</a> 
	</p> 
	</div> 
	
	</div> 
	</div>
    </marquee> 
	</article> 
	<article class="alt"> 
	<div class="content"> 
	<header>
    <span class="blink_text" >JOIN US</span>
    </header> 
	<div class="image fit"> 
	<img src="images/pic02.jpg" alt="" /> 
    </div> 

	<p>If You want To be a part Of our organization click on the following link</p>
    <input type="button" VALUE="REGISTER" onClick="#" class="button alt">
    </div> 
	</article> 
	</div> 
	</section> 
	
	<section id="three" class="marquee1"> 
	<marquee onmouseover="this.stop();" onmouseout="this.start();" direction="left" scrollamount="7" height="360" overflow="hidden" id="mycrawler2"> 
	<img src="img/img1.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img2.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img3.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img4.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img5.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img6.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img7.jpg" style="display: inline; vertical-align: top;  alt="2.jpg">
    <img src="img/img8.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
    </marquee> 
	</section> 
	
	
	<section id="footer"> 
	<div class="inner"> 
	<div class="copyright"> 
	&copy; Event Association: <a href="https://templated.co/">Team 04</a><a href="#">Event</a> 

	</div> 
	</div> 
	</section> 
	
	<script src="assets/js/jquery.min.js"></script> 

	<script src="assets/js/skel.min.js"></script> 

	<script src="assets/js/util.js"></script> 

	<script src="assets/js/main.js"></script> 

	
	</body> 
	</html> 
	

