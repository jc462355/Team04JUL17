<?php
	//must appear BEFORE the <html> tag
	session_start();
	include_once('include/config.php');	
	
	if (isset($_SESSION['valid_user'])) {
		header("location: member_only.php");
	}
	
	//make the database connection
	$conn  = db_connect();
	     
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      $email = $conn -> real_escape_string($_POST['email']);
      $password = $conn -> real_escape_string($_POST['password']); 
     	  
	  //make a query to check if user login successfully
	  $sql = "select * from users where email='$email' and password='$password'";
	  $result = $conn -> query($sql);
	  $numOfRows = $result -> num_rows;
	  $row = $result -> fetch_assoc();
	  if ($numOfRows == 1) {
         $_SESSION['valid_user'] = $email;
		 $_SESSION['name'] = $row['name'];         
         header("location: index.php");
      }else {
		  $error = 'Your Login Name or Password is invalid';
      }
   }
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Event Association Login</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link href="css/nav.css" rel="stylesheet" type="text/css">
<link href="css/rwd.css" rel="stylesheet" type="text/css">
<link href="css/nav_responsive.css" rel="stylesheet" type="text/css">
<link href="css/member.css" rel="stylesheet" type="text/css">
<script src="js/member.js"></script>
<script src="js/nav.js"></script>
</head>
<body onLoad="run_first()">
	<?php include("h1.php") ?>
<h1>Login</h1>
<div class="member_frm">
<p>Please enter your email and password</p>
<form action="login.php" method="post">
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label for="email">Email:</label>
            <input type="email" id="email" name="email" size="35" maxlength="50" 
            	onBlur="changeColor(id, 'white')"
                onFocus="changeColor(id, 'seaShell')" required />
        </div>
    </div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label for="password">Password:</label>
            <input type="password" id="password" name="password" size="20" maxlength="20" 
            	onBlur="changeColor(id, 'white')"
                onFocus="changeColor(id, 'seaShell')" required />
        </div>
    </div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label>&nbsp;</label>
            <input type="submit" id="submit" value="Submit" />
            <input type="reset" id="reset" value="Clear" />
        </div>
    </div>
            
</form>
</div>
<?php 
	if(isset($error)) {
		echo "<p style=\"color: red;\">$error</p>";
		unset($error);
	}
?>
<section id="footer"> 
	<div class="inner"> 
	<div class="copyright"> 
	&copy; Event Association: <a href="https://templated.co/">Team 04</a><a href="#">Event</a> 

	</div> 
	</div> 
	</section>    
    
	<script src="assets/js/jquery.min.js"></script> 

	<script src="assets/js/skel.min.js"></script> 

	<script src="assets/js/util.js"></script> 

	<script src="assets/js/main.js"></script> 
</body>
</html>