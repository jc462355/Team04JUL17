<?php
//must appear BEFORE the <html> tag
session_start();
include_once('include/config.php');	
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>ABC School - Signup</title>
<link href="css/styles.css" rel="stylesheet" type="text/css">
<link href="css/nav.css" rel="stylesheet" type="text/css">
<link href="css/rwd.css" rel="stylesheet" type="text/css">
<link href="css/nav_responsive.css" rel="stylesheet" type="text/css">
<link href="css/member.css" rel="stylesheet" type="text/css">
<script src="js/member.js"></script>
<script src="js/nav.js"></script>
</head>
<body onLoad="run_first()">
	<?php include("h1.php") ?>
<h1>SignUp Form</h1>
<div class="member_frm">
<h2>Please enter your profile</h2>
<p><i>Fields marked with an asterisk (*) must be entered.</i></p>
<form action="member_process.php" method="post">
	<div class="row">
		<div class="col-s-12 col-12">
        	<label for="name">* Name:</label>
            <input type="text" id="name" name="name" size="30" maxlength="50"
            	onBlur="changeColor(id, 'white')"
                onFocus="changeColor(id, 'seaShell')" required />
        </div>
	</div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label for="email">* Email:</label>
            <input type="email" id="email" name="email" size="30" maxlength="50"
                onBlur="changeColor(id, 'white')"
                onFocus="changeColor(id, 'seaShell')" required />
        </div>
    </div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label for="password">* Password:</label>
            <input type="password" id="password" name="password" size="20" maxlength="20"
                onBlur="changeColor(id, 'white')"
                onFocus="changeColor(id, 'seaShell')" required />
            <span id="pwd_msg" class="error_msg"></span>
        </div>
    </div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label for="rePassword">* Re-try:</label>
            <input type="password" id="rePassword" size="20" maxlength="20"
                onChange="checkRePassword(document)"
                onBlur="changeColor(id, 'white')"
                onFocus="changeColor(id, 'seaShell')" />
        </div>
    </div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label for="zip">* Postcode:</label>
            <input type="text" id="zip" size="10" maxlength="10" placeholder="4 digits"
                onChange="checkZIPCode(document)"
                onBlur="changeColor(id, 'white')"
                onFocus="changeColor(id, 'seaShell')" />
            <span class="error_msg" id="zip_msg"></span>
        </div>
    </div>
    <div class="row">
    	<div class="col-s-12 col-12">
        	<label>&nbsp;</label>
            <input type="submit" id="submit" value="Submit" 
            	onClick="return validateInfo(document)" />
            <input type="reset" id="reset" value="Clear Form" onClick="reset_frm(document)" />
        </div>
    </div>            
</form>
</div>
	<?php include("f1.php") ?>

</body>
</html>



