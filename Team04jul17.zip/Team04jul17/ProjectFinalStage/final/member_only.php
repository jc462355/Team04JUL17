<?php
//must appear BEFORE the <html> tag
session_start();
include_once('include/config.php');	
?>

<!doctype html>
<html>
<head> 
	<title>Event Association</title> 
	<meta charset="utf-8" /> 
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" /> 
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
<link rel="stylesheet" href="css/main.css" /> 
<script src="js/member.js"></script>
<script src="assets/js/jquery.min.js"></script> 

	<script src="assets/js/skel.min.js"></script> 

	<script src="assets/js/util.js"></script> 

	<script src="assets/js/main.js"></script> 


	</head> 
<body onLoad="run_first()">
	<?php include("h1.php") ?>
    <h1>Member Page</h1>
	<?php
  	// check session variable
  	if (isset($_SESSION['valid_user']))
  	{
		//make the database connection
		$conn  = db_connect();	
		$user_check = $_SESSION['valid_user'];
   
    	//make a query to check if a valid user
    	$ses_sql = "select name from users where email='$user_check'";
    	$result = $conn -> query($ses_sql);
		if ($result -> num_rows == 1) {
			$row = $result -> fetch_assoc();
			$name = $row['name'];
    		echo "<p>Welcome <b>$name!</b></p>";
			echo "<p><a href=\"logout.php\">Logout</a></p>";
		}
		else {
			echo "<p>Some thing is wrong.</p>";
			echo "<p><a href=\"login.php\">Login</a></p>";
		}
  	}
  	else
  	{
    	echo "<p>You are not logged in.</p>";
		echo "<p><a href=\"login.php\">Login</a></p>";
  	}  
	?> 
   	<?php include("f1.php") ?>

</body>
</html>

