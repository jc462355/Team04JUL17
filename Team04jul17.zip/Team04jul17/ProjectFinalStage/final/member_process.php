<?php
//must appear BEFORE the <html> tag
session_start();
include_once('include/config.php');	
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">

<body onLoad="run_first()">
	<?php include("h1.php") ?>
<?php
if(isset($_POST['name'], $_POST['email'], $_POST['password'])) {
	//make the database connection
	$conn  = db_connect();
	$name = $conn -> real_escape_string($_POST['name']);
	$email = $conn -> real_escape_string($_POST['email']);
	$password = $conn -> real_escape_string($_POST['password']);	
	//create an insert query 	
	$sql = "insert into users (name, email, password) 
			VALUES ('$name', '$email', '$password')";
	//execute the query
	if($conn -> query($sql))
	{
		echo "<h1>Welcome to ABC School</h1>";
		echo "<p>Hi <b>$name</b></p>";
		echo "<p><a href=\"login.php\" id=\"4\" 
				onClick=\"nav_item_selected(4)\">You can login now</a></p>";
	}
	$conn -> close();		
}
else {
	die("Input error");
}
?>    
	<?php include("f1.php") ?>

</body>
</html>



