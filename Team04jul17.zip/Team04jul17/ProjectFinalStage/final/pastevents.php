	<!DOCTYPE HTML> 
	
	<html> 
	<head> 
	<title>Past Events</title> 
	<meta charset="utf-8" /> 
	<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" /> 
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> 
    <link rel="stylesheet" href="css/main.css" /> 
  <link rel="stylesheet" href="css/styles.css" />
	</head> 
	<body>
	<script>
function myFunction() {
    var x = document.getElementById("myTopnav");
    if (x.className === "topnav") {
        x.className += " responsive";
    } else {
        x.className = "topnav";
    }
}
</script>      
	 <header id="header"> 
	<div class="inner"> 
	<a href="index.php" class="logo">Event Association</a> 
   <div class="topnav" id="myTopnav">
   <div class="topnav" id="myTopnav">
 <ul> <a href="index.php">Home</a>
   <a href="about.php">About Us</a> 
 <a href="currentevent.php">Event</a>
  <a href="contact.php">Contact Us</a>
  <ul><?php if(isset($_SESSION['valid_user'])): ?>
  <a href="logout.php" id="4" onClick="nav_item_selected(4)">Sign-out</a>
        <?php else: ?>
		<a href="login.php" id="4" onClick="nav_item_selected(4)">Sign-in</a>
		<?php endif; ?>
		<a href="member.php" id="5" onClick="nav_item_selected(5)">Sign-up</a>
    	
  <a href="javascript:void(0);" style="font-size:15px;" class="icon" onclick="myFunction()">&#9776;</a>
 </ul>

</div>
	</div> 
	</header> 	
<section id="two" > 
<h1 style="color:blue; font-style:italic, bold; font-family:Georgia; font-size:inherit">Past Events  </h1><br/>
<h2 style="color:red; font-style:italic, bold; font-family:Palatino; font-size:inherit">Music Concerts</h2><br/>
	<div class="inner">    
	<article> 
		<img src="img/eminem.jpg" width="100%" height="60%"/>
	</article> 
<article class="alt"> 
	<div class="content"> 
<label for="text"><b>Event Name:</b></label>
<label type="text" style="font-style:italic; color:blue;">Eminem Music Concert</label><br/>
<label for="text"><b>Event Type:</b></label>
<label type="text" style="font-style:italic; color:blue;">Music </label><br/>
<label for="text"><b>Event Date and Time:</b></label>
<label type="text" style="font-style:italic; color:blue;">2nd Sep,2017 and 14:00 </label><br/>
<label for="text"><b>Description:</b></label>
<label type="text" style="font-style:italic; color:blue;">Marshall Bruce Mathers III, known professionally as Eminem, is an American rapper, record producer, and actor. Eminem is the best-selling artist of the 2000s in the United States.</label>

</div>
</article>
</section> 


<section id="two" >
	<div class="inner">
	<article> 
		<img src="img/philippines_all_star.jpg" width="100%" height="60%"/>
	</article> 
<article class="alt"> 
	<div class="content"> 
<label for="text"><b>Event Name:</b></label>
<label type="text" style="font-style:italic; color:blue;">Philippines all star Music Concert</label><br/>
<label for="text"><b>Event Type:</b></label>
<label type="text" style="font-style:italic; color:blue;">Music </label><br/>
<label for="text"><b>Event Date and Time:</b></label>
<label type="text" style="font-style:italic; color:blue;">4th Sep,2017 and 17:00 </label><br/>
<label for="text"><b>Description:</b></label>
<label type="text" style="font-style:italic; color:blue;">The Philippine All-Stars is a Philippine hip-hop dance group. They won the 2006 and 2008 World Hip Hop Dance Championships. They were formed on 2005 by twelve individuals that were working in the Manila underground Hip-hop scene</label>
</div>
</article>
</section> 

<section id="two" > 
	<div class="inner">    
	<article> 
		<img src="img/vamps.jpg" width="100%" height="60%"/>
	</article> 
<article class="alt"> 
	<div class="content"> 
<label for="text"><b>Event Name:</b></label>
<label type="text" style="font-style:italic; color:blue;">Vamp Music Concert</label><br/>
<label for="text"><b>Event Type:</b></label>
<label type="text" style="font-style:italic; color:blue;">Music </label><br/>
<label for="text"><b>Event Date and Time:</b></label>
<label type="text" style="font-style:italic; color:blue;">7th Sep,2017 and 17:00 </label><br/>
<label for="text"><b>Description:</b></label>
<label type="text" style="font-style:italic; color:blue;">The Vamps are a British pop rock band consisting of Brad Simpson (lead vocals and guitar), James McVey (lead guitar and vocals), Connor Ball (bass guitar and vocals) and Tristan Evans (drums and vocals).</label>
</div>
</article>
</section>
<section id="two" > 
<h2 style="color:red; font-style:italic, bold; font-family:Palatino; font-size:inherit">Dance Events</h2><br/>
	<div class="inner">    
	<article> 
		<img src="img/dytto.jpg" width="100%" height="100%"/>
</article> 
<article class="alt"> 
	<div class="content"> 
<label for="text"><b>Event Name:</b></label>
<label type="text" style="font-style:italic; color:blue;">Dytto Dance Concert</label><br/>
<label for="text"><b>Event Type:</b></label>
<label type="text" style="font-style:italic; color:blue;">Dance </label><br/>
<label for="text"><b>Event Date and Time:</b></label>
<label type="text" style="font-style:italic; color:blue;">5th Sep,2017 and 17:00 </label><br/>
<label for="text"><b>Description:</b></label>
<label type="text" style="font-style:italic; color:blue;">Dancer, host, and model known for hosting a music show for World of Dance called The Drop. As a dancer, she displays her unique styles of popping, animation, robotting, tutting, and finger tutting. She also has a YouTube channel with more than 1.7 million subscribers. </label>
</div>
</article>
</section> 
</div> 
</section> 
<h3 style="color:red; font-style:italic, bold; font-family:Palatino; font-size:inherit">Gallery: - </h3>
<section id="three" class="marquee1"> 
	<marquee onmouseover="this.stop();" onmouseout="this.start();" direction="left" scrollamount="7" height="360" overflow="hidden" id="mycrawler2"> 
	<img src="img/img1.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img2.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img3.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img4.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img5.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img6.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
	<img src="img/img7.jpg" style="display: inline; vertical-align: top;  alt="2.jpg">
    <img src="img/img8.jpg" style="display: inline; vertical-align: top;  alt="2.jpg"> 
    </marquee> 
</section>
<section id="footer"> 
	<div class="inner"> 
	<div class="copyright"> 
	&copy; Event Association: <a href="https://templated.co/">Team 04</a><a href="#">Event</a> 

	</div> 
	</div> 
	</section> 
</body> 
</html> 
	

